# -*- coding: utf-8 -*-
#------------------------------------------------------------------------------
# Fichier: test_config.py
# Description: Tests des constantes de configuration
# Encodage: fr_FR.UTF-8
#------------------------------------------------------------------------------

import pytest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))
from config import DECLNCHEURS, ACTIONS, CONTRAINTES, NOM_APPLICATION, VERSION_APPLICATION

class TestConfig:
    """Tests des constantes."""
    
    def test_app_name(self):
        assert NOM_APPLICATION == "macrosTitux"
    
    def test_app_version(self):
        assert VERSION_APPLICATION == "0.3"
    
    def test_triggers_exist(self):
        assert len(DECLNCHEURS) >= 5  # Minimum 5 déclencheurs
    
    def test_actions_exist(self):
        assert len(ACTIONS) >= 5  # Minimum 5 actions
    
    def test_constraints_exist(self):
        assert len(CONTRAINTES) >= 3  # Minimum 3 contraintes
    
    def test_cles_declencheurs_en_majuscules(self):
        for key in DECLNCHEURS.keys():
            assert key.isupper() or '_' in key
    
    def test_cles_action_en_majuscules(self):
        for key in ACTIONS.keys():
            assert key.isupper() or '_' in key
    
    def test_valeurs_declencheurs_non_vides(self):
        for key, value in DECLNCHEURS.items():
            assert value.strip() != ""
    
    def test_valeurs_action_non_vides(self):
        for key, value in ACTIONS.items():
            assert value.strip() != ""

